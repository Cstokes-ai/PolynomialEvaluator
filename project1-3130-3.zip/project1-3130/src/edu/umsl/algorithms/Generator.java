package edu.umsl.algorithms;

import java.math.BigInteger;
import java.util.Random;

public class Generator {
    private static final Random random = new Random();

    public BigInteger[] generateCoefficients(int n, int d) {
        BigInteger[] coefficients = new BigInteger[n + 1];
        for (int i = 0; i <= n; i++) {
            coefficients[i] = generateRandomBigInteger(BigInteger.valueOf(d));
        }
        return coefficients;
    }

    public BigInteger generateXValue(int d) {
        return generateRandomBigInteger(BigInteger.valueOf(d));
    }

    private BigInteger generateRandomBigInteger(BigInteger numDigits) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < numDigits.intValue(); i++) {
            sb.append(random.nextInt(10)); // Append a random digit (0-9)
        }
        return new BigInteger(sb.toString());
    }
}
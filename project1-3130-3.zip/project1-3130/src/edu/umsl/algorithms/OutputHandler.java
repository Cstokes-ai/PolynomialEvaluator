package edu.umsl.algorithms;

import java.math.BigInteger;

public class OutputHandler {
    public void printResult(String algorithm, BigInteger result, double elapsedTime) {
        System.out.println("Algorithm: " + algorithm);
        System.out.println("Result: " + result);
        System.out.println("Time taken: " + elapsedTime + " milliseconds\n");
    }

    // Method to compare results of different algorithms
    public boolean compareResults(BigInteger result1, BigInteger result2, BigInteger result3) {
        return (result1.toString().equals(result2.toString())) && (result2.toString().equals(result3.toString()));
    }
}

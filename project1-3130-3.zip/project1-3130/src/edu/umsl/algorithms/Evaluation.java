package edu.umsl.algorithms;

import java.math.BigInteger;

public class Evaluation {

    public BigInteger BruteForce(BigInteger[] coefficients, BigInteger x) {
        BigInteger result = BigInteger.ZERO;
        for (int i = 0; i < coefficients.length; i++) {
            BigInteger term = BigInteger.ONE;

            // Multiply x by itself i times to calculate x^i
            for (int j = 0; j < i; j++) {
                term = term.multiply(x);
            }

            // Multiply the coefficient by the calculated term
            result = result.add(coefficients[i].multiply(term));
        }

        return result;
    }

    public BigInteger RepeatedSquare(BigInteger[] coefficients, BigInteger x) {
        BigInteger result = BigInteger.ZERO;
        BigInteger powerX = BigInteger.ONE;
        for (int i = 0; i < coefficients.length; i++) {
            result = result.add(coefficients[i].multiply(powerX));
            powerX = powerX.multiply(x);
        }
        return result;
    }

    public BigInteger HornersRule(BigInteger[] coefficients, BigInteger x) {
        BigInteger result = BigInteger.ZERO;
        for (int i = coefficients.length - 1; i >= 0; i--) {
            result = result.multiply(x).add(coefficients[i]);
        }
        return result;
    }

    public BigInteger overflow(BigInteger result) {
        try {
            // Check if the result is negative (indicating overflow)
            if (result.compareTo(BigInteger.ZERO) < 0) {
                throw new ArithmeticException("Overflow occurred");
            }
            // If no overflow, return the result
            return result;
        } catch (ArithmeticException e) {
            // Handle overflow here
            System.err.println("Overflow occurred: " + e.getMessage());
            return BigInteger.valueOf(-1); // Indicate overflow
        }
    }
}
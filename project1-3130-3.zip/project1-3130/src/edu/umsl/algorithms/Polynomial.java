package edu.umsl.algorithms;

import java.math.BigInteger;

public class Polynomial {

    public static void main(String[] args) {

        // Create instances of other classes
        Evaluation evaluator = new Evaluation();
        Generator generator = new Generator();
        OutputHandler outputHandler = new OutputHandler();
        BigIntPolynomial bigIntPolynomial = new BigIntPolynomial();

        // Generate polynomial coefficients and value for x
        BigInteger n = BigInteger.valueOf(1000); // Degree of the polynomial
        BigInteger d = BigInteger.valueOf(4); // Number of digits for coefficients and x value
        BigInteger[] coefficients = generator.generateCoefficients(n.intValue(), d.intValue());
        BigInteger x = generator.generateXValue(d.intValue());

        System.out.println("Generated X value: " + x);

        // Print polynomial coefficients
        System.out.println("Polynomial Coefficients:");
        for (int i = 0; i < coefficients.length; i++) {
            System.out.println("Coefficient[" + i + "]: " + coefficients[i]);
        }
        System.out.println();

        // Evaluate polynomial using different algorithms
        long startTime, endTime;
        double elapsedTime;

        // Evaluate using brute force method
        startTime = System.currentTimeMillis();
        BigInteger resultBruteForce = evaluator.BruteForce(coefficients, x);
        endTime = System.currentTimeMillis();
        elapsedTime = (endTime - startTime) / 1000.0;
        outputHandler.printResult("Brute Force", resultBruteForce, elapsedTime);

        // Evaluate using repeated squaring technique
        startTime = System.currentTimeMillis();
        BigInteger resultRepeatedSquaring = evaluator.RepeatedSquare(coefficients, x);
        endTime = System.currentTimeMillis();
        elapsedTime = (endTime - startTime) / 1000.0;
        outputHandler.printResult("Repeated Squaring", resultRepeatedSquaring, elapsedTime);

        // Evaluate using Horner's Rule
        startTime = System.currentTimeMillis();
        BigInteger resultHorner = evaluator.HornersRule(coefficients, x);
        endTime = System.currentTimeMillis();
        elapsedTime = (endTime - startTime) / 1000.0;
        outputHandler.printResult("Horner's Rule", resultHorner, elapsedTime);

        // Evaluate using BigIntPolynomial
        BigInteger bigIntResult = bigIntPolynomial.evaluate(coefficients, x);
        System.out.println("Algorithm: BigIntPolynomial");
        System.out.println("Result: " + bigIntResult + "\n");

        // Compare results
        boolean sameResults = outputHandler.compareResults(resultBruteForce, resultRepeatedSquaring, resultHorner);
        if (sameResults) {
            System.out.println("Results of all algorithms are the same.");
        } else {
            System.out.println("Results of algorithms are different.");
        }
    }
}
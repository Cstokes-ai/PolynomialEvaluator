package edu.umsl.algorithms;
import java.math.BigInteger;
public class BigIntPolynomial {
    public BigInteger evaluate(BigInteger[] coefficients, BigInteger x) {
        BigInteger result = BigInteger.ZERO;

        for (int i = 0; i < coefficients.length; i++) {
            BigInteger term = BigInteger.ONE;

            // Multiply x by itself i times to calculate x^i
            for (int j = 0; j < i; j++) {
                term = term.multiply(x);
            }

            // Multiply the coefficient by the calculated term
            result = result.add(coefficients[i].multiply(term));
        }
        return result;
    }
}
